library (baycn)

# Load the data
load('../data_ge_N_200.RData')
load('../bay_nc11_cf.RData')

# Load command line arguments 
args <- commandArgs(trailingOnly = TRUE)

# extract the iteration of interest (for the for loop) for this file from the 
# command line arguments
run <- as.integer(args[1])

if (is.na(run)) {
  stop("No Run was defined")
}

# Adjacency matrices -----------------------------------------------------------

# Adjacency matrix with the all edges for topology NC11.
am_nc11 <- matrix(c(0,  1,  1,  1,  1,  1,  1,  1,  1,   1,   1,
                    1,  0,  1,  1,  1,  1,  1,  1,  1,   1,   1,
                    1,  1,  0,  1,  1,  1,  1,  1,  1,   1,   1,
                    1,  1,  1,  0,  1,  1,  1,  1,  1,   1,   1,
                    1,  1,  1,  1,  0,  1,  1,  1,  1,   1,   1,
                    1,  1,  1,  1,  1,  0,  1,  1,  1,   1,   1,
                    1,  1,  1,  1,  1,  1,  0,  1,  1,   1,   1,
                    1,  1,  1,  1,  1,  1,  1,  0,  1,   1,   1,
                    1,  1,  1,  1,  1,  1,  1,  1,  0,   1,   1,
                    1,  1,  1,  1,  1,  1,  1,  1,  1,   0,   1,
                    1,  1,  1,  1,  1,  1,  1,  1,  1,   1,   0),
                  byrow = TRUE,
                  nrow = 11)

# Note the inputs for cycleFndr were already generated and stored in 
# './bay_nc11_cf.RData'

# Run baycn on each data set. --------------------------------------------------

set.seed(122)

# Loop through each combination of signal strength and sample size for all
# topologies.
print(paste("This is run:", run))
for (e in run:run) {

  # 0.2 -------------------------------------------

  bay_nc11_200_02 <- mhEdge(adjMatrix = am_nc11,
                                 burnIn = 0.2,
                                 data = data_nc11_200_02[[e]],
                                 iterations = 2000,
                                 nGV = 0,
                                 pmr = FALSE,
                                 prior = c(0.05,
                                           0.05,
                                           0.9),
                                 thinTo = 200,
                                 progress = FALSE,
                                 inpCf = cf)

  # 0.5 -------------------------------------------

  bay_nc11_200_05 <- mhEdge(adjMatrix = am_nc11,
                                 burnIn = 0.2,
                                 data = data_nc11_200_05[[e]],
                                 iterations = 2000,
                                 nGV = 0,
                                 pmr = FALSE,
                                 prior = c(0.05,
                                           0.05,
                                           0.9),
                                 thinTo = 200,
                                 progress = FALSE,
                                 inpCf = cf)
  # 1 ---------------------------------------------

  bay_nc11_200_1 <- mhEdge(adjMatrix = am_nc11,
                                burnIn = 0.2,
                                data = data_nc11_200_1[[e]],
                                iterations = 2000,
                                nGV = 0,
                                pmr = FALSE,
                                prior = c(0.05,
                                          0.05,
                                          0.9),
                                thinTo = 200,
                                progress = TRUE,
                                 inpCf = cf)

  print(e)
  print(Sys.time())

}

save(M,
     bay_nc11_200_02,
     bay_nc11_200_05,
     bay_nc11_200_1,
     file = paste('./bay_ge_N_200_nc11_run_', run, '.RData', sep=""))


