#!/bin/bash
#SBATCH -q primary
#SBATCH -N 1-1
#SBATCH -n 1
#SBATCH --mem=48G
#SBATCH --mail-type=ALL
#SBATCH --mail-user=hp8415@wayne.edu
#SBATCH -o out/nc11.output_%j.out
#SBATCH -e out/nc11.errors_%j.err
#SBATCH -t 9-0:0:0
#SBATCH --job-name nc11
#SBATCH --array=1-25

Rscript bay_ge_N_600_nc11.R ${SLURM_ARRAY_TASK_ID}
